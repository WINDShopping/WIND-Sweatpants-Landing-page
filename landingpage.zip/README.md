# Landing Page - Electric Biker

This is a simple landing page built with HTML, Tailwind CSS, and custom JavaScript.

## 🚀 How to Deploy on GitHub Pages

1. Create a new repository on GitHub (e.g., `landingpage`).
2. Upload the files from this project (`index.html`, `README.md`) to the repository.
3. Go to **Settings > Pages** in your repository.
4. Under "Branch", select `main` and `/ (root)` then save.
5. Your site will be live at:  
   `https://username.github.io/landingpage/`
